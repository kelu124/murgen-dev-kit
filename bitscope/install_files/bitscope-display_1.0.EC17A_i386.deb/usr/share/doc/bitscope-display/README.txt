 --------------------------------------------------------------------

              BITSCOPE DISPLAY DIAGNOSTIC APPLICATION

                   Display Version 1.0 Build EC17A

              http://www.bitscope.com/software/dso/

   Copyright (C) 2014 by BitScope Designs. All Rights Reserved.

 --------------------------------------------------------------------

 BitScope Display is a cross-platform tool to help analyze your system
 graphical user interface performance. It is a GUI application itself,
 not a benchmark tool. It's designed to a offer practical insight into
 how well your system will  perform when running real-time interactive
 graphical applications like those  we've created for BitScope. Issues
 that can  affect performance  include graphics hardware,  drivers and
 graphical acceleration plugins, and GUI frameworks used.

 User interaction  impacts  such as mouse movement  and widget updates
 can also be tested in the  context of live display refresh mechanisms
 available on each platform.

 This application was  developed to help our  work optimising BitScope
 software for use on low  powered platforms including Raspberry Pi. In
 our investigations we found things which can help many other systems,
 not just Raspberry Pi. We've  released this tool for those interested
 to explore these performance characteristics on their own systems.
 
 Display is available for Windows, Linux, Mac OSX & ARM/Raspberry Pi.
 --------------------------------------------------------------------
                  BitScope Designs. Mar 17, 2014.
 --------------------------------------------------------------------
