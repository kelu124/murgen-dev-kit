 ---------------------------------------------------------------------

              BITLINK - BITSCOPE COMMUNICATIONS LIBRARY

                             VERSION 1.0

      Copyright (C) 2016 by BitScope Designs. All Rights Reserved.

 ---------------------------------------------------------------------

 The BITSCOPE  COMMUNICATIONS LIBRARY (BITLINK) is  function based API
 for communicating any  model BitScope. It allows the  user to connect
 to and control all available BitScopes.

 The library API is documented in BitLink.html. The API is simply a
 set of functions to open  a device, send commands and receive replies
 from a BitScope.  This version of the API has  been coded for Delphi,
 C, VBA  and LabView, but  a similar file  can be coded in  almost any
 other language that supports shared object files.

 The  function definitions  can also  be found  in the  C  header file
 /usr/include/bitlink.h. You can use the headers to import the library
 functions into your C code. An  example of how to do this is included
 in the BitLinkConsole package.
 
 ---------------------------------------------------------------------
                 BitScope Designs. January 05, 2016.
 ---------------------------------------------------------------------
