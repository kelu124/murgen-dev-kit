 --------------------------------------------------------------------

            BITSCOPE PROTO - OSCILLOSCOPE (PROTOTYPE)

                        BETA Version 0.9

              http://www.bitscope.com/software/proto/

   Copyright (C) 2015 by BitScope Designs. All Rights Reserved.

 --------------------------------------------------------------------

 This app demonstrates how to use the BitScope Library to build simple
 oscilloscope applications using any supported BitScope model.

 --------------------------------------------------------------------
