 ---------------------------------------------------------------------

       BITSCOPE DIGITAL OSCILLOSCOPE AND LOGIC ANALYZER SERVER

                     Version 1.1 Build FK26A

              http://www.bitscope.com/software/server/

     Copyright (C) 2016 by BitScope Designs. All Rights Reserved.

 ---------------------------------------------------------------------

 BitScope  Server  makes  BitScopes  available  as  network  connected
 devices via UDP or TCP transport  layers in the same way that Network
 BitScopes  do natively.  It allows  USB  and Serial  BitScopes to  be
 accessed via  the network when connected  to a PC or  embedded system
 (e.g. Raspberry Pi).
 
   Send comments, bug reports, suggestions to support@bitscope.com.
 
 ---------------------------------------------------------------------
                  BitScope Designs. Jan 05, 2016.
 ---------------------------------------------------------------------
