 --------------------------------------------------------------------

              BITSCOPE CONSOLE - TALKING TO BITSCOPE

                   Version 1.0 Build FK29A

              http://www.bitscope.com/software/library/

   Copyright (C) 2016 by BitScope Designs. All Rights Reserved.

 --------------------------------------------------------------------
 
 --------------------------------------------------------------------
                   BitScope Designs. Jan 5, 2016
 --------------------------------------------------------------------
