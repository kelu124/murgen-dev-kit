 ---------------------------------------------------------------------

                 BITLIB - BITSCOPE PROGRAMMING LIBRARY

      Copyright (C) 2010 by BitScope Designs. All Rights Reserved.

 --------------------------------------------------------------------

     This is BETA SOFTWARE. It  has bugs and it is missing some
     of the features of the production release. It designed for
     testing and  debugging but it  should be quite  stable and
     usable in most situations.

 ---------------------------------------------------------------------

 The BITGEN LIBRARY is function  based API for programming a BitGen
 Waveform Generator chip, which is an optional component available for
 the BS100 model BitScope. The BitGenLib library allows the user to 
 connect to and control all aspects of the BitGen chip.


 NOTE: The BitLib library is required for the BitGenLib library. 
       BitLib can be downloaded free of charge from the BitScope
       website.


 This file is a brief introduction to the BitGenLib demo source. The 
 documentation is in the file BitGenDemoSource.html which is included 
 in this zip file. For information on specific BitGenLib library 
 functions please see the file BitGenAPI.html which is also included 
 in this package. For more information on using the BitGenLib demo 
 applications, see the file BitGenDemo.html also included in this 
 package. 

 Please see the documentation file BitGenDemoSource.html for 
 information on building the projects.

 ---------------------------------------------------------------------

 WHAT IS BITSCOPE ?
 ----------------

 BitScope is a mixed signal (analog + digital) data capture engine for
 use with a PC. It is  programmable and can be configured as a digital
 storage oscilloscope, a logic  analyzer, a data acquisition device, a
 waveform synthesizer or a  combination of these via readable "capture
 scripts" executing on a virtual machine inside the BitScope itself.
 
 Because programming is script driven, any PC programming environment,
 language or software application that can manipulate ASCII strings is
 suitable for use with BitScope. Examples include Excel, Visual Basic,
 MatLab, LabVIEW, Java, Delphi, Perl, Python, Tcl/Tk, HP VEE etc.
 
 BitScope uses a simple  stateless protocol with an implicit handshake
 to transmit  scripts eliminating the need for  complex state machines
 or hardware flow control.  This means different host interface types,
 including RS-232, USB and UDP/IP (Ethernet), can all be used the same
 way (as far as the PC software is concerned).

 ---------------------------------------------------------------------

 WHAT IS BITGEN ?
 ----------------

 BitGen is a integrated DSP based waveform generator and timing 
 generator for a USB BitScope 100. The BitGen is an optional extra to 
 the BS100.

 The BitGen has the following key features:

 * Standard generator wave-functions.
 * User programmable arbitrary waveforms.
 * Continuous, burst, chirp, and noise modes.
 * Crystal referenced vari-clock, DDS and PRNG.
 * Frequency precision better than 1ppm (DDS).
 * Sample jitter below 10nS (variable clock).
 * Event timing precision better than 50nS.
 * Synchronized clock/timing channel.
 * Scope probe compensation signal.
 * Clock and voltage generation.
 * Logic family level shifter.

 BitGen can generate and capture standard wave-functions, clocks, 
 triggers, one-shot bursts, sweeps, chirps, pink/white noise, arbitrary 
 waveforms or even waveforms previously captured with BitScope.

 The BitGenLib library allows developers to create custom applications 
 to control all aspects of the BitGen.

 If you would like to order a BitGen chip, or read more about it, you 
 can view the BitGen web page http://www.bitscope.com/product/DWG100/.

 ---------------------------------------------------------------------

 GETTING STARTED
 ---------------

 First you will need to unpack the zip file bitgenlib-src-w32-<version>.zip,
 where <version> is the BitGenLib software version number and the build id. 
 This command will extract the documentation into the sub-directory 
 bitgenlib-src-w32-<version>


 ---------------------------------------------------------------------

 INSTALLED FILES
 ---------

 These are the files that should be installed on your system:

 bitgenlib-src-w32-<version number>
 |
 |-- README.txt
 |-- BitGenAPI.html
 |-- BitGenDemo.html
 |-- BitGenDemoSource.html
 |-- BitLibAPI.html
 |-- LICENSE.txt
 |
 `-- Generator
     |-- BitGenAPI.pas
     |-- BitLibAPI.pas
     |-- DisplayUnit.pas
     |-- GeneratorUnit.pas
     |-- WinGenerator.lpi
     `-- WinGenerator.lpr

 ---------------------------------------------------------------------

 DEMOS
 -----

 The bitgenlib demo source package contains the source for the 
 Generator demo. The Generator is a simple waveform generator for use 
 with the BitGenLib library and DWG BitGen chips. 

 NOTE: BitLib and BitGenLib is required for the Generator demo.

 For information on how to build the sources, please see the 
 documentation file BitGenDemoSource.html included in this package.

 ---------------------------------------------------------------------

 PROBE FILE (BitScope.prb)
 ----------
 
 The probe file defines where the library should look to find BitScope
 devices you have  connected to your PC. Read the BitGenLib documentation
 BitGenAPI.html for information on the probe file.

 ---------------------------------------------------------------------

 LIBRARY API
 -----------

 The library API is documented in the BitGenLib package in the file 
 BitGenAPI.html. The API is simply a set of BitScope functions that are
 included in the BitGenLib library.  This version of the API has been used
 to code applications in Delphi and C, but an application that uses 
 BitGenLib can be coded in any other language that supports external 
 shared object files.
 
 ---------------------------------------------------------------------

 BUGS
 ----
 As this software is in beta release, we appreciate any comments or 
 suggestions you have to improve the software. Please send feedback 
 to project@bitscope.com.

 ---------------------------------------------------------------------
               BitScope Designs. July 14, 2010.
 ---------------------------------------------------------------------
